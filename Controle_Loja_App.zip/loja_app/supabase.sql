-- Banco de dados para o aplicativo Controle Loja
create extension if not exists pgcrypto;
create table if not exists products(id uuid primary key default gen_random_uuid(), code text unique not null, name text not null, category text, size text, color text, cost numeric(12,2) default 0, price numeric(12,2) default 0, min_stock numeric(12,2) default 0, created_at timestamptz default now());
create table if not exists stock_entries(id uuid primary key default gen_random_uuid(), entry_date timestamptz not null default now(), product_code text not null references products(code), quantity numeric(12,2) not null check(quantity>0), unit_cost numeric(12,2) default 0, supplier text, created_at timestamptz default now());
create table if not exists sales(id uuid primary key default gen_random_uuid(), sale_date timestamptz not null default now(), total numeric(12,2) not null default 0, payment_method text, installments integer default 1, created_at timestamptz default now());
create table if not exists sale_items(id uuid primary key default gen_random_uuid(), sale_id uuid not null references sales(id) on delete cascade, product_code text not null references products(code), quantity numeric(12,2) not null check(quantity>0), unit_price numeric(12,2) not null default 0, discount numeric(8,4) default 0);
create index if not exists idx_entries_product on stock_entries(product_code); create index if not exists idx_sales_date on sales(sale_date); create index if not exists idx_items_product on sale_items(product_code);
alter table products enable row level security; alter table stock_entries enable row level security; alter table sales enable row level security; alter table sale_items enable row level security;
-- MVP compartilhado: qualquer usuário autenticado pode operar. Para uso em produção, crie perfis/roles e restrinja por loja/usuário.
create policy "auth products" on products for all to authenticated using (true) with check (true);
create policy "auth entries" on stock_entries for all to authenticated using (true) with check (true);
create policy "auth sales" on sales for all to authenticated using (true) with check (true);
create policy "auth sale items" on sale_items for all to authenticated using (true) with check (true);
