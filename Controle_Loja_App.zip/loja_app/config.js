// Preencha com os dados do seu projeto Supabase.
// A chave ANON/PUBLIC pode ficar no navegador quando o RLS estiver configurado corretamente.
window.SUPABASE_URL = '';
window.SUPABASE_ANON_KEY = '';
