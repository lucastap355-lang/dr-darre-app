# Controle Loja — aplicativo PWA

Aplicativo móvel baseado na planilha Dashboard_Loja_Roupas-1.xlsx.

## O que já está implementado
- Dashboard com KPIs
- Cadastro de produtos
- Entrada de estoque
- PDV/venda
- Baixa automática do estoque
- Status OK / REPOR / ZERADO / NEGATIVO
- Consulta de estoque com busca
- Relatório de vendas
- PWA instalável no celular
- Banco Supabase opcional
- Modo demonstração local para testar a interface

## Colocar na nuvem
1. Crie um projeto no Supabase.
2. Abra SQL Editor e execute `supabase.sql`.
3. Copie URL e chave ANON/PUBLIC do projeto para `config.js`.
4. Publique esta pasta em qualquer hospedagem HTTPS (Netlify, Vercel, GitHub Pages etc.).
5. Abra no celular e use "Adicionar à tela inicial".

## Segurança
Não use a `service_role` key no navegador. Use somente a chave ANON/PUBLIC com RLS. Para produção, recomenda-se autenticação e perfis de usuário/loja.
